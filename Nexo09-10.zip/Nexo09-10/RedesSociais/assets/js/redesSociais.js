// Animação de scroll para a página de Redes Sociais
document.addEventListener('DOMContentLoaded', function() {
  const elementos = {
    titulo: document.querySelector('.redes-titulo'),
    linha1: document.querySelector('.redes-linha:nth-child(2)'),
    divisor: document.querySelector('.redes-divider'),
    linha2: document.querySelector('.redes-linha:nth-child(4)'),
    itens: document.querySelectorAll('.rede-item-com-imagem')
  };

  function verificarScroll() {
    const windowHeight = window.innerHeight;
    const triggerBottom = windowHeight * 0.85;

    // Animar elementos principais
    if (elementos.titulo) {
      const tituloTop = elementos.titulo.getBoundingClientRect().top;
      if (tituloTop < triggerBottom) {
        elementos.titulo.classList.add('visible');
      } else {
        elementos.titulo.classList.remove('visible');
      }
    }

    if (elementos.linha1) {
      const linha1Top = elementos.linha1.getBoundingClientRect().top;
      if (linha1Top < triggerBottom) {
        elementos.linha1.classList.add('visible');
      } else {
        elementos.linha1.classList.remove('visible');
      }
    }

    if (elementos.divisor) {
      const divisorTop = elementos.divisor.getBoundingClientRect().top;
      if (divisorTop < triggerBottom) {
        elementos.divisor.classList.add('visible');
      } else {
        elementos.divisor.classList.remove('visible');
      }
    }

    if (elementos.linha2) {
      const linha2Top = elementos.linha2.getBoundingClientRect().top;
      if (linha2Top < triggerBottom) {
        elementos.linha2.classList.add('visible');
      } else {
        elementos.linha2.classList.remove('visible');
      }
    }

    // Animar itens com imagens com delay
    elementos.itens.forEach((item, index) => {
      const itemTop = item.getBoundingClientRect().top;
      
      if (itemTop < triggerBottom) {
        setTimeout(() => {
          item.classList.add('visible');
        }, index * 200);
      } else {
        item.classList.remove('visible');
      }
    });

    // Efeito fade out
    const section = document.querySelector('.redes-sociais-section');
    if (section) {
      const sectionBottom = section.getBoundingClientRect().bottom;
      const sectionTop = section.getBoundingClientRect().top;
      
      if (sectionTop > windowHeight || sectionBottom < 0) {
        Object.keys(elementos).forEach(key => {
          if (elementos[key] && elementos[key].classList) {
            if (key === 'itens') {
              elementos.itens.forEach(item => item.classList.add('fade-out'));
            } else {
              elementos[key].classList.add('fade-out');
            }
          }
        });
      }
    }
  }

  // Verificar scroll inicial
  verificarScroll();

  // Adicionar event listener para scroll
  window.addEventListener('scroll', verificarScroll);
  window.addEventListener('resize', verificarScroll);
});
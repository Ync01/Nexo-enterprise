// Timeline com Scroll Suave e Animações
document.addEventListener('DOMContentLoaded', function() {
    const timelineItems = document.querySelectorAll('.timeline-item');
    const navDots = document.querySelectorAll('.nav-dot');
    const progressBar = document.querySelector('.progress-bar');
    const scrollIndicator = document.querySelector('.scroll-indicator');
    let currentIndex = 0;
    let isScrolling = false;
    let scrollTimeout;

    // Criar bolinha móvel
    const timelineMarker = document.createElement('div');
    timelineMarker.className = 'timeline-marker';
    document.body.appendChild(timelineMarker);

    // Configuração inicial
    function initTimeline() {
        setActiveItem(0);
        setupTechChips();
        updateMarkerPosition();
        
        // Event listeners
        window.addEventListener('scroll', handleScroll, { passive: true });
        window.addEventListener('wheel', handleWheel, { passive: false });
        window.addEventListener('keydown', handleKeydown);
        window.addEventListener('resize', updateMarkerPosition);
        
        navDots.forEach((dot, index) => {
            dot.addEventListener('click', () => goToSection(index));
        });
    }

    // Scroll com wheel - controle suave
    function handleWheel(e) {
        if (isScrolling) return;
        
        // Clear existing timeout
        if (scrollTimeout) {
            clearTimeout(scrollTimeout);
        }
        
        scrollTimeout = setTimeout(() => {
            if (e.deltaY > 50 && currentIndex < timelineItems.length - 1) {
                e.preventDefault();
                goToSection(currentIndex + 1);
            } else if (e.deltaY < -50 && currentIndex > 0) {
                e.preventDefault();
                goToSection(currentIndex - 1);
            }
        }, 100);
    }

    // Scroll automático com detecção suave
    function handleScroll() {
        if (isScrolling) return;
        
        updateMarkerPosition();
        
        const scrollY = window.scrollY + (window.innerHeight * 0.3); // 30% da tela
        
        timelineItems.forEach((item, index) => {
            const rect = item.getBoundingClientRect();
            const itemTop = rect.top + window.scrollY;
            const itemBottom = itemTop + rect.height;
            
            if (scrollY >= itemTop && scrollY < itemBottom) {
                if (index !== currentIndex) {
                    setActiveItem(index);
                }
            }
        });
    }

    // Atualizar posição da bolinha
    function updateMarkerPosition() {
        const scrollY = window.scrollY;
        const windowHeight = window.innerHeight;
        const documentHeight = document.documentElement.scrollHeight - windowHeight;
        
        if (documentHeight > 0) {
            const scrollPercentage = Math.min(scrollY / documentHeight, 1);
            const markerTop = 10 + (scrollPercentage * 80); // 10% a 90% da tela
            
            timelineMarker.style.top = `${markerTop}vh`;
        }
    }

    // Ir para seção com animação
    function goToSection(index) {
        if (isScrolling || index < 0 || index >= timelineItems.length) return;
        
        isScrolling = true;
        
        timelineItems[index].scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
        
        setActiveItem(index);
        
        setTimeout(() => {
            isScrolling = false;
        }, 1000);
    }

    // Definir item ativo com animações
    function setActiveItem(index) {
        currentIndex = index;
        
        timelineItems.forEach((item, i) => {
            if (i === index) {
                setTimeout(() => {
                    item.classList.add('active');
                }, 300);
            } else {
                item.classList.remove('active');
            }
        });
        
        updateNavDots();
        updateProgress();
        
        scrollIndicator.classList.toggle('hidden', currentIndex === timelineItems.length - 1);
    }

    // Atualizar dots
    function updateNavDots() {
        navDots.forEach((dot, index) => {
            dot.classList.toggle('active', index === currentIndex);
        });
    }

    // Atualizar progresso
    function updateProgress() {
        const progress = (currentIndex / (timelineItems.length - 1)) * 100;
        progressBar.style.width = `${progress}%`;
    }

    // Teclado
    function handleKeydown(e) {
        if (isScrolling) return;
        
        if (e.key === 'ArrowDown' && currentIndex < timelineItems.length - 1) {
            e.preventDefault();
            goToSection(currentIndex + 1);
        } else if (e.key === 'ArrowUp' && currentIndex > 0) {
            e.preventDefault();
            goToSection(currentIndex - 1);
        } else if (e.key >= '1' && e.key <= '5') {
            e.preventDefault();
            goToSection(parseInt(e.key) - 1);
        }
    }

    // Tech Chips
    function setupTechChips() {
        const techChips = document.querySelectorAll('.tech-chip');
        
        const popupOverlay = document.createElement('div');
        popupOverlay.className = 'popup-overlay';
        
        const techPopup = document.createElement('div');
        techPopup.className = 'tech-popup';
        techPopup.innerHTML = `
            <div class="popup-header">
                <h3 class="popup-title"></h3>
                <button class="popup-close">&times;</button>
            </div>
            <div class="popup-content">
                <p></p>
            </div>
        `;
        
        document.body.appendChild(popupOverlay);
        document.body.appendChild(techPopup);
        
        const popupTitle = techPopup.querySelector('.popup-title');
        const popupContent = techPopup.querySelector('.popup-content p');
        const popupClose = techPopup.querySelector('.popup-close');
        
        function openPopup(tech, description) {
            popupTitle.textContent = tech;
            popupContent.textContent = description;
            popupOverlay.classList.add('active');
            techPopup.classList.add('active');
            document.addEventListener('keydown', handleEscapeKey);
        }
        
        function closePopup() {
            popupOverlay.classList.remove('active');
            techPopup.classList.remove('active');
            document.removeEventListener('keydown', handleEscapeKey);
        }
        
        function handleEscapeKey(e) {
            if (e.key === 'Escape') closePopup();
        }
        
        techChips.forEach(chip => {
            chip.addEventListener('click', function() {
                const tech = this.getAttribute('data-tech');
                const description = this.getAttribute('data-description');
                openPopup(tech, description);
            });
        });
        
        popupClose.addEventListener('click', closePopup);
        popupOverlay.addEventListener('click', closePopup);
        techPopup.addEventListener('click', (e) => e.stopPropagation());
    }

    // Inicializar
    initTimeline();
    
    // Animar título
    const timelineTitle = document.querySelector('.timeline-title');
    if (timelineTitle) {
        setTimeout(() => {
            timelineTitle.style.animation = 'titleEntry 1s ease-out 0.5s forwards';
        }, 300);
    }
});
// darkMode.js
document.addEventListener('DOMContentLoaded', function() {
    const toggleSwitch = document.querySelector('#checkbox');
    
    if (!toggleSwitch) {
        console.error('Toggle switch não encontrado!');
        return;
    }
    
    const currentTheme = localStorage.getItem('theme');
    const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;

    // Aplicar tema inicial
    applyTheme(currentTheme, systemPrefersDark);

    // Event listener para o toggle switch
    toggleSwitch.addEventListener('change', function(e) {
        if (e.target.checked) {
            applyTheme('dark');
        } else {
            applyTheme('light');
        }
    });

    // Observar mudanças na preferência do sistema
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
        if (!localStorage.getItem('theme')) {
            applyTheme(e.matches ? 'dark' : 'light');
        }
    });

    function applyTheme(theme, systemPrefersDark = false) {
    if (!theme) {
        theme = systemPrefersDark ? 'dark' : 'light';
    }
    
    // Primeiro: aplicar fade out na imagem atual
    const bgImg = document.querySelector('.background img');
    if (bgImg) {
        bgImg.style.opacity = '0';
        
        // Usar setTimeout para garantir o fade out antes da troca
        setTimeout(() => {
            if (theme === 'light') {
                bgImg.src = 'assets/img/background-white.jpg';
            } else {
                bgImg.src = 'assets/img/background.png';
            }
            
            // Fade in da nova imagem
            setTimeout(() => {
                bgImg.style.opacity = '1';
            }, 0);
        }, 300); // Match com a duração da transição CSS (0.3s = 300ms)
    }
    
    // Aplicar o tema ao DOM (um pouco depois para sincronizar)
    setTimeout(() => {
        document.documentElement.setAttribute('data-theme', theme);
        localStorage.setItem('theme', theme);
        
        if (toggleSwitch) {
            toggleSwitch.checked = (theme === 'dark');
        }
    },);
}
});
// Módulo de Acessibilidade Atualizado
const Accessibility = (() => {
    // Configurações
    const settings = {
        animationDuration: 300,
        localStorageKey: 'nexoAccessibilitySettings',
        defaultSettings: {
            fontSize: 'normal', // 'smaller', 'normal', 'larger'
            highContrast: false,
            animations: true
        }
    };

    // Estado
    let state = { ...settings.defaultSettings };
    let isMenuOpen = false;

    // Elementos do DOM
    const elements = {
        btn: null,
        menu: null,
        options: null
    };

    // Inicialização
    function init() {
        console.log('Inicializando módulo de acessibilidade...');
        
        // Carregar elementos
        elements.btn = document.getElementById('accessibilityBtn');
        elements.menu = document.getElementById('accessibilityMenu');
        elements.options = document.querySelectorAll('.accessibility-option');
        
        if (!elements.btn || !elements.menu) {
            console.error('Elementos de acessibilidade não encontrados!');
            return;
        }

        // Carregar configurações salvas
        loadSettings();
        
        // Configurar eventos
        setupEventListeners();
        
        // Aplicar configurações iniciais
        applySettings();
        
        // Inicializar menu como fechado
        elements.menu.style.display = 'none';
        
        console.log('Módulo de acessibilidade inicializado com sucesso!');
    }

    // Carregar configurações salvas
    function loadSettings() {
        try {
            const savedSettings = localStorage.getItem(settings.localStorageKey);
            const savedFontSize = localStorage.getItem('fontSize');
            
            if (savedSettings) {
                state = { ...state, ...JSON.parse(savedSettings) };
            }
            
            // Carregar tamanho da fonte antigo (para compatibilidade)
            if (savedFontSize) {
                const size = parseFloat(savedFontSize);
                document.documentElement.style.setProperty('--font-size-base', savedFontSize + 'px');
                
                // Atualizar classes de feedback visual
                if (size > 16) {
                    document.body.classList.add('font-larger');
                    state.fontSize = 'larger';
                } else if (size < 16) {
                    document.body.classList.add('font-smaller');
                    state.fontSize = 'smaller';
                } else {
                    document.body.classList.add('font-normal');
                    state.fontSize = 'normal';
                }
                
                // Remover a chave antiga
                localStorage.removeItem('fontSize');
                saveSettings();
            }
            
            console.log('Configurações carregadas:', state);
        } catch (error) {
            console.error('Erro ao carregar configurações:', error);
        }
    }

    // Salvar configurações
    function saveSettings() {
        try {
            localStorage.setItem(settings.localStorageKey, JSON.stringify(state));
        } catch (error) {
            console.error('Erro ao salvar configurações:', error);
        }
    }

    // Aplicar configurações
    function applySettings() {
        const { fontSize, highContrast, animations } = state;
        const { body } = document;
        
        // Aplicar tamanho da fonte
        body.classList.remove('font-smaller', 'font-normal', 'font-larger');
        body.classList.add(`font-${fontSize}`);
        
        // Aplicar alto contraste
        if (highContrast) {
            body.classList.add('high-contrast');
        } else {
            body.classList.remove('high-contrast');
        }
        
        // Aplicar animações
        if (!animations) {
            body.classList.add('no-animations');
        } else {
            body.classList.remove('no-animations');
        }
    }

    // Alternar visibilidade do menu
    function toggleMenu() {
        isMenuOpen ? closeMenu() : openMenu();
    }

    // Abrir menu
    function openMenu() {
        if (isMenuOpen) return;
        
        const { btn, menu } = elements;
        
        // Fechar outros menus abertos
        closeAllMenus();
        
        // Atualizar atributos ARIA
        btn.setAttribute('aria-expanded', 'true');
        menu.setAttribute('aria-hidden', 'false');
        
        // Mostrar menu
        menu.style.display = 'flex';
        
        // Forçar reflow para ativar a animação
        void menu.offsetWidth;
        
        // Adicionar classe para animação
        menu.classList.add('show');
        
        // Atualizar estado
        isMenuOpen = true;
        
        // Remover foco automático do primeiro item do menu
        // Isso evita que qualquer item fique selecionado por padrão
    }

    // Fechar menu
    function closeMenu() {
        if (!isMenuOpen) return;
        
        const { btn, menu } = elements;
        
        // Atualizar atributos ARIA
        btn.setAttribute('aria-expanded', 'false');
        menu.setAttribute('aria-hidden', 'true');
        
        // Remover classe para animação
        menu.classList.remove('show');
        
        // Atualizar estado
        isMenuOpen = false;
        
        // Esconder menu após a animação
        setTimeout(() => {
            if (!isMenuOpen) {
                menu.style.display = 'none';
            }
        }, settings.animationDuration);
        
        // Retornar o foco para o botão
        btn.focus();
    }

    // Fechar todos os menus de acessibilidade
    function closeAllMenus() {
        document.querySelectorAll('.accessibility-menu').forEach(menu => {
            if (menu !== elements.menu) {
                menu.classList.remove('show');
                menu.setAttribute('aria-hidden', 'true');
                menu.previousElementSibling?.setAttribute('aria-expanded', 'false');
            }
        });
    }

    // Configurar eventos
    function setupEventListeners() {
        const { btn, menu, options } = elements;
        
        // Clique no botão de acessibilidade
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            toggleMenu();
        });
        
        // Teclado no botão de acessibilidade
        btn.addEventListener('keydown', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                toggleMenu();
            } else if (e.key === 'Escape' && isMenuOpen) {
                closeMenu();
            }
        });
        
        // Clique fora do menu
        document.addEventListener('click', function(e) {
            if (isMenuOpen && !menu.contains(e.target) && !btn.contains(e.target)) {
                closeMenu();
            }
        });
        
        // Tecla ESC para fechar menu
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape' && isMenuOpen) {
                closeMenu();
            }
        });
        
        // Eventos para as opções do menu
        options.forEach(option => {
            // Clique na opção
            option.addEventListener('click', function(e) {
                e.stopPropagation();
                const action = this.getAttribute('data-action');
                handleOptionAction(action);
                
                // Fechar menu após um curto atraso para feedback visual
                setTimeout(() => {
                    closeMenu();
                }, 300);
            });
            
            // Teclado na opção
            option.addEventListener('keydown', function(e) {
                if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    const action = this.getAttribute('data-action');
                    handleOptionAction(action);
                    closeMenu();
                } else if (e.key === 'Escape') {
                    closeMenu();
                } else if (e.key === 'Tab' && !e.shiftKey && this === options[options.length - 1]) {
                    // Se for o último item e pressionar Tab, voltar para o primeiro
                    e.preventDefault();
                    options[0].focus();
                } else if (e.key === 'Tab' && e.shiftKey && this === options[0]) {
                    // Se for o primeiro item e pressionar Shift+Tab, ir para o último
                    e.preventDefault();
                    options[options.length - 1].focus();
                } else if (e.key === 'ArrowDown') {
                    // Navegação com setas
                    e.preventDefault();
                    const next = this.nextElementSibling || options[0];
                    next.focus();
                } else if (e.key === 'ArrowUp') {
                    e.preventDefault();
                    const prev = this.previousElementSibling || options[options.length - 1];
                    prev.focus();
                }
            });
        });
    }

    // Manipular ações das opções do menu
    function handleOptionAction(action) {
        switch (action) {
            case 'increase-font':
                increaseFontSize();
                showFeedback('Tamanho da fonte aumentado');
                break;
            case 'decrease-font':
                decreaseFontSize();
                showFeedback('Tamanho da fonte diminuído');
                break;
            case 'read-page':
                readPageContent();
                break;
        }
    }

    // Aumentar tamanho da fonte
    function increaseFontSize() {
        const html = document.documentElement;
        let currentSize = parseFloat(getComputedStyle(html).fontSize);
        const newSize = Math.min(currentSize * 1.1, 22); // Limite máximo de 22px
        
        // Atualizar variável CSS
        html.style.setProperty('--font-size-base', newSize + 'px');
        
        // Atualizar estado
        if (newSize > 16) {
            state.fontSize = 'larger';
            document.body.classList.remove('font-smaller', 'font-normal');
            document.body.classList.add('font-larger');
        } else {
            state.fontSize = 'normal';
            document.body.classList.remove('font-smaller', 'font-larger');
            document.body.classList.add('font-normal');
        }
        
        // Salvar configurações
        saveSettings();
    }

    // Diminuir tamanho da fonte
    function decreaseFontSize() {
        const html = document.documentElement;
        let currentSize = parseFloat(getComputedStyle(html).fontSize);
        const newSize = Math.max(currentSize / 1.1, 12); // Limite mínimo de 12px
        
        // Atualizar variável CSS
        html.style.setProperty('--font-size-base', newSize + 'px');
        
        // Atualizar estado
        if (newSize < 16) {
            state.fontSize = 'smaller';
            document.body.classList.remove('font-normal', 'font-larger');
            document.body.classList.add('font-smaller');
        } else {
            state.fontSize = 'normal';
            document.body.classList.remove('font-smaller', 'font-larger');
            document.body.classList.add('font-normal');
        }
        
        // Salvar configurações
        saveSettings();
    }

    // Ler conteúdo da página
    function readPageContent() {
        if ('speechSynthesis' in window) {
            // Se já estiver falando, parar a fala
            if (speechSynthesis.speaking) {
                speechSynthesis.cancel();
                showFeedback('Leitura interrompida');
                return;
            }
            
            // Obter o conteúdo principal da página
            const mainContent = document.querySelector('main, .container, .content, #content') || document.body;
            const textToRead = mainContent.innerText || mainContent.textContent;
            
            if (textToRead && textToRead.trim().length > 0) {
                const utterance = new SpeechSynthesisUtterance(textToRead);
                
                // Configurações de voz
                utterance.lang = 'pt-BR';
                utterance.rate = 1.0;
                utterance.pitch = 1.0;
                utterance.volume = 1.0;
                
                // Evento quando a fala terminar
                utterance.onend = function() {
                    showFeedback('Leitura concluída');
                };
                
                // Iniciar fala
                speechSynthesis.speak(utterance);
                showFeedback('Lendo conteúdo da página...');
            } else {
                showFeedback('Nenhum conteúdo para ler');
            }
        } else {
            showFeedback('Seu navegador não suporta leitura de tela');
        }
    }

    // Mostrar feedback visual
    function showFeedback(message) {
        // Verificar se já existe um elemento de feedback
        let feedback = document.querySelector('.accessibility-feedback');
        
        // Criar elemento de feedback se não existir
        if (!feedback) {
            feedback = document.createElement('div');
            feedback.className = 'accessibility-feedback';
            document.body.appendChild(feedback);
        }
        
        // Atualizar mensagem
        feedback.textContent = message;
        
        // Mostrar feedback com animação
        setTimeout(() => {
            feedback.style.opacity = '1';
            feedback.style.visibility = 'visible';
        }, 10);
        
        // Esconder feedback após 3 segundos
        clearTimeout(feedback.timeoutId);
        feedback.timeoutId = setTimeout(() => {
            feedback.style.opacity = '0';
            feedback.style.visibility = 'hidden';
        }, 3000);
    }

    // Inicializar quando o DOM estiver pronto
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        // DOM já está pronto
        init();
    }
    
    // Retornar API pública
    return {
        toggleMenu,
        increaseFontSize,
        decreaseFontSize,
        readPageContent
    };
})();

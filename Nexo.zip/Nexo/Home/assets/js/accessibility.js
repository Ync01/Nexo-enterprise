// Adicione esta linha para depuração
console.log('Arquivo accessibility.js carregado!');

// Função para alternar o menu de acessibilidade
function toggleAccessibilityMenu(button) {
    const menu = document.querySelector('.accessibility-menu');
    if (!menu) return;
    
    const isVisible = menu.classList.contains('show');
    
    // Fechar todos os menus de acessibilidade abertos
    document.querySelectorAll('.accessibility-menu').forEach(m => {
        if (m !== menu) {
            m.classList.remove('show');
            m.style.opacity = '0';
            m.style.visibility = 'hidden';
            m.style.transform = 'translateY(10px)';
        }
    });
    
    // Alternar o menu atual
    if (isVisible) {
        menu.style.opacity = '0';
        menu.style.visibility = 'hidden';
        menu.style.transform = 'translateY(10px)';
        menu.classList.remove('show');
        button.setAttribute('aria-expanded', 'false');
    } else {
        menu.style.opacity = '1';
        menu.style.visibility = 'visible';
        menu.style.transform = 'translateY(0)';
        menu.classList.add('show');
        button.setAttribute('aria-expanded', 'true');
        
        // Focar no primeiro item do menu para melhor acessibilidade
        const firstItem = menu.querySelector('.accessibility-option');
        if (firstItem) {
            setTimeout(() => {
                firstItem.focus();
            }, 100);
        }
    }
}

// Função para carregar as preferências salvas
function loadPreferences() {
    const body = document.body;
    
    // Verificar preferências salvas
    if (localStorage.getItem('highContrast') === 'enabled') {
        body.classList.add('high-contrast');
    }
    if (localStorage.getItem('fontSize') === 'larger') {
        body.classList.add('larger-font');
    } else if (localStorage.getItem('fontSize') === 'smaller') {
        body.classList.add('smaller-font');
    }
}

// Função para lidar com os cliques nos botões de acessibilidade
function handleAccessibilityClick(e) {
    e.preventDefault();
    e.stopPropagation();
    
    const button = e.target.closest('.accessibility-option');
    if (!button) return;
    
    const action = button.getAttribute('data-action');
    const body = document.body;
    
    console.log('Botão clicado:', action); // Log de depuração
    
    // Remover feedback visual de todos os botões
    document.querySelectorAll('.accessibility-option').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Adicionar feedback visual ao botão clicado
    button.classList.add('active');
    
    switch(action) {
        case 'increase-font':
            body.classList.remove('smaller-font');
            body.classList.add('larger-font');
            localStorage.setItem('fontSize', 'larger');
            showFeedback('Tamanho da fonte aumentado');
            break;
            
        case 'decrease-font':
            body.classList.remove('larger-font');
            body.classList.add('smaller-font');
            localStorage.setItem('fontSize', 'smaller');
            showFeedback('Tamanho da fonte diminuído');
            break;
            
        case 'high-contrast':
            const isHighContrast = !body.classList.contains('high-contrast');
            body.classList.toggle('high-contrast');
            
            if (isHighContrast) {
                localStorage.setItem('highContrast', 'enabled');
                showFeedback('Alto contraste ativado');
            } else {
                localStorage.removeItem('highContrast');
                showFeedback('Alto contraste desativado');
            }
            break;
            
        case 'read-page':
            if ('speechSynthesis' in window) {
                // Verificar se já está lendo
                if (window.speechSynthesis.speaking) {
                    window.speechSynthesis.cancel();
                    showFeedback('Leitura interrompida');
                } else {
                    const speech = new SpeechSynthesisUtterance();
                    const mainContent = document.querySelector('main') || document.body;
                    speech.text = mainContent.innerText.replace(/\s+/g, ' ').trim();
                    speech.volume = 1;
                    speech.rate = 1;
                    speech.pitch = 1;
                    
                    speech.onend = function() {
                        showFeedback('Leitura concluída');
                    };
                    
                    window.speechSynthesis.speak(speech);
                    showFeedback('Lendo conteúdo da página...');
                }
            } else {
                showFeedback('Seu navegador não suporta leitura de texto');
            }
            break;
    }
    
    // Fechar o menu após a seleção
    const menu = document.querySelector('.accessibility-menu');
    if (menu) {
        menu.style.opacity = '0';
        menu.style.visibility = 'hidden';
        menu.style.transform = 'translateY(10px)';
        menu.classList.remove('show');
    }
}

// Função para exibir feedback visual
function showFeedback(message) {
    // Remover feedback anterior se existir
    let feedback = document.querySelector('.accessibility-feedback');
    
    if (!feedback) {
        feedback = document.createElement('div');
        feedback.className = 'accessibility-feedback';
        document.body.appendChild(feedback);
    }
    
    feedback.textContent = message;
    feedback.style.opacity = '1';
    feedback.style.visibility = 'visible';
    
    // Esconder o feedback após 3 segundos
    setTimeout(() => {
        feedback.style.opacity = '0';
        setTimeout(() => {
            feedback.style.visibility = 'hidden';
        }, 300);
    }, 3000);
}

// Inicialização quando o DOM estiver pronto
document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM totalmente carregado!'); // Log de depuração
    
    // Carregar preferências
    loadPreferences();
    
    // Adicionar evento de clique ao botão de acessibilidade
    const accessibilityBtn = document.querySelector('.accessibility-btn');
    const accessibilityMenu = document.querySelector('.accessibility-menu');
    
    if (accessibilityBtn && accessibilityMenu) {
        console.log('Elementos de acessibilidade encontrados!'); // Log de depuração
        
        // Adicionar evento de clique ao botão principal
        accessibilityBtn.addEventListener('click', function(e) {
            e.stopPropagation();
            toggleAccessibilityMenu(this);
        });
        
        // Adicionar evento de clique aos botões de opção
        const options = accessibilityMenu.querySelectorAll('.accessibility-option');
        options.forEach(option => {
            option.addEventListener('click', handleAccessibilityClick);
            
            // Adicionar feedback tátil ao clicar
            option.addEventListener('mousedown', function() {
                this.style.transform = 'scale(0.95)';
            });
            
            option.addEventListener('mouseup', function() {
                this.style.transform = '';
            });
            
            option.addEventListener('mouseleave', function() {
                this.style.transform = '';
            });
        });
    } else {
        console.error('Elementos de acessibilidade não encontrados!');
        if (!accessibilityBtn) console.error('Botão de acessibilidade não encontrado!');
        if (!accessibilityMenu) console.error('Menu de acessibilidade não encontrado!');
    }
    
    // Fechar o menu ao clicar fora dele
    document.addEventListener('click', function(e) {
        const accessibilityBtn = document.querySelector('.floating-accessibility-btn');
        const menu = document.querySelector('.accessibility-menu');
        
        if (menu && menu.classList.contains('visible') && 
            !accessibilityBtn.contains(e.target) && 
            !e.target.closest('.accessibility-menu')) {
            
            menu.style.opacity = '0';
            menu.style.visibility = 'hidden';
            menu.style.transform = 'translateY(10px)';
            menu.classList.remove('visible');
        }
    });
});

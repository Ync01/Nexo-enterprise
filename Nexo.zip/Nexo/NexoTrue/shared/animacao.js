// === reveal.js ===
// Aplica a animação de surgimento em qualquer elemento com a classe .reveal

(function() {
    // Fallback caso IntersectionObserver não exista
    if (!('IntersectionObserver' in window)) {
      document.querySelectorAll('.reveal').forEach(el => el.classList.add('is-visible'));
      return;
    }
  
    const elements = document.querySelectorAll('.reveal');
  
    const observer = new IntersectionObserver((entries, obs) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          obs.unobserve(entry.target); // Para não reanimar depois
        }
      });
    }, {
      threshold: 0.2,
      rootMargin: '0px 0px -10% 0px'
    });
  
    elements.forEach(el => observer.observe(el));
  })();
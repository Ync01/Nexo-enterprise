// redesSociais.js - VERSÃO CORRIGIDA SEM DUPLICAÇÃO

// Dados das redes sociais
const redesSociaisInfo = {
    'instagram': {
        nome: 'Instagram',
        criador: 'Kevin Systrom e Mike Krieger',
        anoCriacao: 2010,
        usuarios: '1.4 bilhões',
        descricao: 'Plataforma para compartilhamento de fotos e vídeos.'
    },
    'youtube': {
        nome: 'YouTube',
        criador: 'Chad Hurley, Steve Chen e Jawed Karim',
        anoCriacao: 2005,
        usuarios: '2.5 bilhões',
        descricao: 'Maior plataforma de compartilhamento de vídeos do mundo.'
    },
    'facebook': {
        nome: 'Facebook',
        criador: 'Mark Zuckerberg',
        anoCriacao: 2004,
        usuarios: '2.9 bilhões',
        descricao: 'Rede social que conecta pessoas ao redor do mundo.'
    },
    'whatsapp': {
        nome: 'WhatsApp',
        criador: 'Jan Koum e Brian Acton',
        anoCriacao: 2009,
        usuarios: '2 bilhões',
        descricao: 'Aplicativo de mensagens instantâneas.'
    },
    'tiktok': {
        nome: 'TikTok',
        criador: 'Zhang Yiming',
        anoCriacao: 2016,
        usuarios: '1.2 bilhões',
        descricao: 'Plataforma de vídeos curtos e entretenimento.'
    },
    'discord': {
        nome: 'Discord',
        criador: 'Jason Citron',
        anoCriacao: 2015,
        usuarios: '350 milhões',
        descricao: 'Plataforma de comunicação para comunidades e gamers.'
    }
};

// Função para abrir pop-up
function abrirPopup(rede) {
    console.log('Tentando abrir pop-up para:', rede);
    
    const info = redesSociaisInfo[rede];
    if (!info) {
        console.log('Rede não encontrada:', rede);
        return;
    }

    // Criar overlay
    const overlay = document.createElement('div');
    overlay.className = 'popup-overlay';
    overlay.innerHTML = `
        <div class="popup-content">
            <button class="fechar-popup">&times;</button>
            <h2>${info.nome}</h2>
            <div class="popup-info">
                <p><strong>Criador:</strong> ${info.criador}</p>
                <p><strong>Ano de Criação:</strong> ${info.anoCriacao}</p>
                <p><strong>Usuários Ativos:</strong> ${info.usuarios}</p>
                <p><strong>Descrição:</strong> ${info.descricao}</p>
            </div>
        </div>
    `;

    document.body.appendChild(overlay);

    // Mostrar pop-up
    setTimeout(() => overlay.classList.add('active'), 10);

    // Configurar fechamento
    const fecharBtn = overlay.querySelector('.fechar-popup');
    fecharBtn.onclick = () => fecharPopup(overlay);
    
    overlay.onclick = (e) => {
        if (e.target === overlay) fecharPopup(overlay);
    };

    document.addEventListener('keydown', function escHandler(e) {
        if (e.key === 'Escape') fecharPopup(overlay, escHandler);
    });
}

// Função para fechar pop-up
function fecharPopup(overlay, escHandler) {
    overlay.classList.remove('active');
    setTimeout(() => {
        if (document.body.contains(overlay)) {
            document.body.removeChild(overlay);
        }
        if (escHandler) {
            document.removeEventListener('keydown', escHandler);
        }
    }, 300);
}

// Animação de scroll para a página
function configurarAnimacaoScroll() {
    const elementos = [
        '.redes-titulo',
        '.redes-linha',
        '.redes-divider', 
        '.rede-item-com-imagem'
    ];

    function verificarScroll() {
        const windowHeight = window.innerHeight;
        const triggerBottom = windowHeight * 0.85;

        elementos.forEach(selector => {
            const elements = document.querySelectorAll(selector);
            elements.forEach(element => {
                const elementTop = element.getBoundingClientRect().top;
                if (elementTop < triggerBottom) {
                    element.classList.add('visible');
                }
            });
        });
    }

    // Verificar scroll inicial
    verificarScroll();

    // Adicionar event listeners
    window.addEventListener('scroll', verificarScroll);
    window.addEventListener('resize', verificarScroll);
}

// ÚNICA função DOMContentLoaded
document.addEventListener('DOMContentLoaded', function() {
    console.log('Página carregada - configurando pop-ups');
    
    // Adicionar eventos de clique a todos os itens de rede social
    const itens = document.querySelectorAll('.rede-item-com-imagem');
    console.log('Encontrados', itens.length, 'itens');
    
    itens.forEach(item => {
        const nomeRede = item.querySelector('.rede-nome').textContent.toLowerCase();
        console.log('Configurando:', nomeRede);
        
        // Usar once: false para garantir que só um listener seja adicionado
        item.addEventListener('click', function(e) {
            e.preventDefault();
            console.log('Clicou em:', nomeRede);
            abrirPopup(nomeRede);
        }, { once: false });
        
        item.style.cursor = 'pointer';
    });
    
    // Configurar animação de scroll
    configurarAnimacaoScroll();
    
    // Garantir que o conteúdo esteja visível
    setTimeout(() => {
        document.querySelectorAll('.redes-conteudo').forEach(el => {
            el.style.opacity = '1';
            el.style.transform = 'none';
        });
    }, 100);
});